# scripts

This folder contains scripted functions and scripted classes used by the game.

Fun fact! Although scripted functions require the target script to be in a specific location, the scripted class can be anywhere as long as it extends the appropriate target class. Directory structure for scripted classes is mainly for organizational purposes.
